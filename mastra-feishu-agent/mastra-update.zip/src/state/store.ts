import { mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { createClient, type Client } from '@libsql/client';
import { config } from '../config';

export type ActionStatus = 'pending' | 'executing' | 'succeeded' | 'failed' | 'denied' | 'expired' | 'interrupted';
export type StoredAction = {
  id: string;
  kind: string;
  payload: string;
  requester_id: string;
  chat_id: string;
  chat_type: 'p2p' | 'group' | null;
  status: ActionStatus;
  created_at: number;
  expires_at: number;
  result: string | null;
  tool_call_id: string | null;
  session_id: string | null;
};

let clientPromise: Promise<Client> | undefined;

export async function stateDb(): Promise<Client> {
  if (clientPromise) return clientPromise;
  clientPromise = initializeStateDb().catch(error => {
    clientPromise = undefined;
    throw error;
  });
  return clientPromise;
}

async function initializeStateDb(): Promise<Client> {
  mkdirSync(config.dataDir, { recursive: true });
  const db = createClient({ url: `file:${join(config.dataDir, 'state.db')}` });
  await db.execute(`CREATE TABLE IF NOT EXISTS actions (
    id TEXT PRIMARY KEY,
    kind TEXT NOT NULL,
    payload TEXT NOT NULL,
    requester_id TEXT NOT NULL,
    chat_id TEXT NOT NULL,
    chat_type TEXT,
    status TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL,
    result TEXT,
    tool_call_id TEXT,
    session_id TEXT
  )`);
  const actionColumns = await db.execute('PRAGMA table_info(actions)');
  if (!actionColumns.rows.some(row => row.name === 'chat_type')) {
    try {
      await db.execute('ALTER TABLE actions ADD COLUMN chat_type TEXT');
    } catch (error) {
      if (!(error instanceof Error) || !error.message.includes('duplicate column name')) throw error;
    }
  }
  await db.execute(`CREATE TABLE IF NOT EXISTS seen_messages (
    message_id TEXT PRIMARY KEY,
    seen_at INTEGER NOT NULL
  )`);
  await db.execute(`CREATE TABLE IF NOT EXISTS workflow_jobs (
    id TEXT PRIMARY KEY,
    run_id TEXT,
    requester_id TEXT NOT NULL,
    chat_id TEXT NOT NULL,
    status TEXT NOT NULL,
    result TEXT,
    updated_at INTEGER NOT NULL
  )`);
  await db.execute(`CREATE TABLE IF NOT EXISTS permission_requests (
    id TEXT PRIMARY KEY,
    requester_id TEXT NOT NULL,
    chat_id TEXT NOT NULL,
    payload TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL
  )`);
  await db.execute(`CREATE INDEX IF NOT EXISTS permission_requests_lookup ON permission_requests(requester_id, chat_id, status)`);
  await db.execute(`CREATE TABLE IF NOT EXISTS user_tokens (
    user_id TEXT PRIMARY KEY,
    encrypted_token TEXT NOT NULL,
    encrypted_refresh_token TEXT,
    expires_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL
  )`);
  return db;
}

export async function markMessageSeen(messageId: string): Promise<boolean> {
  const db = await stateDb();
  const result = await db.execute({ sql: 'INSERT OR IGNORE INTO seen_messages(message_id, seen_at) VALUES (?, ?)', args: [messageId, Date.now()] });
  return result.rowsAffected === 1;
}

export async function recoverInterruptedApprovals(): Promise<number> {
  const db = await stateDb();
  const result = await db.execute({
    sql: "UPDATE actions SET status = 'interrupted' WHERE status = 'executing' OR (status = 'pending' AND kind = 'mastra_tool')",
    args: [],
  });
  return result.rowsAffected;
}

export async function recoverInterruptedWorkflows(): Promise<number> {
  const db = await stateDb();
  const result = await db.execute({
    sql: "UPDATE workflow_jobs SET status = 'interrupted', updated_at = ? WHERE status = 'running'",
    args: [Date.now()],
  });
  return result.rowsAffected;
}

export async function getAction(id: string): Promise<StoredAction | null> {
  const db = await stateDb();
  const result = await db.execute({ sql: 'SELECT * FROM actions WHERE id = ?', args: [id] });
  return (result.rows[0] as unknown as StoredAction | undefined) ?? null;
}
