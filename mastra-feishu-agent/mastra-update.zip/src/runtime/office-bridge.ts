import { createLarkChannel, type LarkChannel } from '@larksuiteoapi/node-sdk';
import { requireFeishuConfig } from '../config';
import { approvalCard } from '../gateway/cards';
import { OfficeApi, createOfficeTransport } from '../office/client';

let current: OfficeApi | undefined;
let studioChannel: LarkChannel | undefined;
export function setOfficeApi(api: OfficeApi | undefined) { current = api; }
function getStudioChannel(): LarkChannel {
  studioChannel ??= createLarkChannel({ ...requireFeishuConfig(), transport: 'websocket' });
  return studioChannel;
}
export function getOfficeApi(): OfficeApi {
  return current ?? new OfficeApi(createOfficeTransport(getStudioChannel()));
}

export async function sendStudioApprovalCard(chatId: string, actionId: string, summary: string) {
  await getStudioChannel().send(chatId, { card: approvalCard(actionId, summary) });
}
