import { FeishuGateway } from './gateway';

const gateway = new FeishuGateway();
await gateway.start();
console.log('Feishu gateway connected. Mastra Studio: http://127.0.0.1:4111');

for (const signal of ['SIGINT', 'SIGTERM'] as const) {
  process.once(signal, () => { void gateway.stop().finally(() => process.exit(0)); });
}
