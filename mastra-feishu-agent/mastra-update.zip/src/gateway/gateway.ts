import { createLarkChannel, type CardActionEvent, type LarkChannel, type NormalizedMessage } from '@larksuiteoapi/node-sdk';
import { RequestContext } from '@mastra/core/request-context';
import type { Server } from 'node:http';
import { z } from 'zod';
import { config, requireFeishuConfig } from '../config';
import { isAuthorizedCaller, isAuthorizedMessage, memoryKeys, type Caller } from '../identity';
import { controller } from '../mastra';
import { minutesToTasksWorkflow } from '../mastra/workflows/minutes-to-tasks';
import { officeTools } from '../mastra/tools/office-tools';
import { OfficeApi, createOfficeTransport } from '../office/client';
import { actionResultDetail, officeAction } from '../office/actions';
import { completeCalendarAuthorization, latestPermissionRequestId, resolvePermissionReply, setPermissionNotifier } from '../office/permission-choice';
import { startOAuthCallback, userAccessToken } from '../office/user-auth';
import { setApprovalNotifier } from '../runtime/approval-bridge';
import { setOfficeApi } from '../runtime/office-bridge';
import { APPROVAL_TTL_MS, decideAction, expireAction, proposeAction } from '../state/approvals';
import { getAction, markMessageSeen, recoverInterruptedApprovals, recoverInterruptedWorkflows, stateDb } from '../state/store';
import { approvalCard, cardDecision, resolvedCard } from './cards';

type Session = Awaited<ReturnType<typeof controller.createSession>>;
const minutesCommand = /^\/minutes\s+([\w@.-]+)\s*$/i;
const idCommand = /^\/id$/i;
const officeToolNames = new Set(Object.keys(officeTools));

export class FeishuGateway {
  readonly channel: LarkChannel;
  readonly office: OfficeApi;
  private readonly sessions = new Map<string, Session>();
  private readonly queues = new Map<string, Promise<void>>();
  private readonly activeRuns = new Map<string, { unsubscribe: () => void }>();
  private oauthServer: Server | undefined;

  constructor(channel?: LarkChannel) {
    this.channel = channel ?? createLarkChannel({
      ...requireFeishuConfig(),
      transport: 'websocket',
      // Receive @bot messages from groups; the gateway checks their identity and mention.
      policy: { requireMention: true, dmMode: 'open' },
      safety: { chatQueue: { enabled: false }, batch: { text: { delayMs: 0 }, media: { delayMs: 0 } } },
      handshakeTimeoutMs: 15_000,
    });
    this.office = new OfficeApi(createOfficeTransport(this.channel));
  }

  async start() {
    await stateDb();
    await recoverInterruptedApprovals();
    await recoverInterruptedWorkflows();
    await controller.init();
    setOfficeApi(this.office);
    setApprovalNotifier(async (chatId, actionId, summary) => {
      await this.channel.send(chatId, { card: approvalCard(actionId, summary) });
    });
    setPermissionNotifier(async (chatId, text) => { await this.channel.send(chatId, { text }); });
    this.oauthServer = await startOAuthCallback(completeCalendarAuthorization);
    this.channel.on('message', message => { void this.enqueue(message).catch(error => this.report(error)); });
    this.channel.on('cardAction', event => { void this.onCardAction(event).catch(error => this.report(error)); });
    this.channel.on('error', error => this.report(error));
    await this.channel.connect();
  }

  async stop() {
    for (const run of this.activeRuns.values()) run.unsubscribe();
    this.activeRuns.clear();
    setApprovalNotifier(undefined);
    setPermissionNotifier(undefined);
    setOfficeApi(undefined);
    await new Promise<void>(resolve => this.oauthServer?.close(() => resolve()) ?? resolve());
    await this.channel.disconnect();
  }

  private report(error: unknown) {
    console.error(error instanceof Error ? error.message : String(error));
  }

  private enqueue(message: NormalizedMessage): Promise<void> {
    const before = this.queues.get(message.chatId) ?? Promise.resolve();
    const after = before.catch(() => {}).then(() => this.onMessage(message));
    this.queues.set(message.chatId, after);
    void after.finally(() => { if (this.queues.get(message.chatId) === after) this.queues.delete(message.chatId); }).catch(() => {});
    return after;
  }

  async onMessage(message: NormalizedMessage) {
    const content = message.content.trim();
    if (!content) return;
    const lookupId = idCommand.test(content) && (message.chatType === 'p2p' || message.mentionedBot);
    if (!lookupId && !isAuthorizedMessage(message)) return;
    if (!(await markMessageSeen(message.messageId))) return;
    try {
      if (lookupId) {
        const text = message.chatType === 'p2p'
          ? message.senderId.startsWith('ou_')
            ? `你的 open_id：${message.senderId}\n当前私聊 chat_id：${message.chatId}`
            : `当前私聊 chat_id：${message.chatId}\n飞书事件未提供 open_id，请检查机器人消息权限。`
          : `当前群 chat_id：${message.chatId}\n个人 open_id 请私聊机器人发送 /id。`;
        await this.channel.send(message.chatId, { text }, { replyTo: message.messageId });
        return;
      }
      const caller: Caller = { userId: message.senderId, chatId: message.chatId, chatType: message.chatType };
      if (await resolvePermissionReply(caller, content)) return;
      const command = minutesCommand.exec(content);
      if (command) {
        await this.runMinutesWorkflow(command[1], caller, message.messageId);
      } else {
        await this.runAgent(content, caller, message.messageId, message.createTime);
      }
    } catch (error) {
      this.report(error);
      await this.channel.send(message.chatId, { text: '处理失败。请检查模型代理、飞书权限和服务日志。' }, { replyTo: message.messageId });
    }
  }

  private async sessionFor(caller: Caller) {
    const keys = memoryKeys(caller);
    let session = this.sessions.get(keys.sessionId);
    if (!session) {
      session = await controller.createSession({ id: keys.sessionId, resourceId: keys.resourceId, threadId: keys.threadId });
      await session.permissions.setForCategory({ category: 'execute', policy: 'ask' });
      this.sessions.set(keys.sessionId, session);
    }
    return session;
  }

  private async runAgent(content: string, caller: Caller, replyTo: string, messageCreatedAt = Date.now()) {
    const session = await this.sessionFor(caller);
    const permissionRequestBefore = await latestPermissionRequestId(caller);
    const sessionId = memoryKeys(caller).sessionId;
    if (this.activeRuns.has(sessionId)) {
      await this.channel.send(caller.chatId, { text: '上一轮操作仍在处理或等待确认，请先处理审批卡片。' }, { replyTo });
      return;
    }
    let reply = '';
    let finished = false;
    const finish = async (sendReply: boolean) => {
      if (finished) return;
      finished = true;
      unsubscribe();
      try {
        if (sendReply && reply.trim() && await latestPermissionRequestId(caller) === permissionRequestBefore) {
          await this.channel.send(caller.chatId, { markdown: reply }, { replyTo });
        }
      } finally {
        this.activeRuns.delete(sessionId);
      }
    };
    const unsubscribe = session.subscribe(event => {
      if (event.type === 'message_update' && event.event.type === 'text-delta') reply += event.event.delta;
      if (event.type === 'tool_approval_required') {
        void this.onToolApproval(event, caller, session).catch(error => this.report(error));
      }
      if (event.type === 'agent_end' && event.reason !== 'suspended') {
        void finish(event.reason !== 'error').catch(error => this.report(error));
      }
    });
    this.activeRuns.set(sessionId, { unsubscribe });
    try {
      const requestContext = new RequestContext();
      requestContext.set('caller', caller);
      requestContext.set('originalMessage', content);
      requestContext.set('messageCreatedAt', messageCreatedAt > 0 ? messageCreatedAt : Date.now());
      await session.sendMessage({ content, requestContext, author: { id: caller.userId } });
    } catch (error) {
      await finish(false);
      throw error;
    }
  }

  private async onToolApproval(event: { toolCallId: string; toolName: string; args: unknown }, caller: Caller, session: Session) {
    if (officeToolNames.has(event.toolName)) {
      // Office writes create their own approval only after resolving identity and target.
      await session.respondToToolApproval({ toolCallId: event.toolCallId, decision: 'approve' });
      return;
    }
    const argumentText = JSON.stringify(event.args) ?? 'null';
    if (argumentText.length > 3_500) {
      await session.respondToToolApproval({ toolCallId: event.toolCallId, decision: 'decline' });
      throw new Error(`Approval details for ${event.toolName} exceed the card display limit`);
    }
    const keys = memoryKeys(caller);
    const proposal = await proposeAction(caller, { kind: 'mastra_tool', toolName: event.toolName, arguments: event.args }, {
      toolCallId: event.toolCallId, sessionId: keys.sessionId,
    });
    try {
      await this.channel.send(caller.chatId, { card: approvalCard(proposal.id, `${event.toolName}\n${argumentText}`) });
      const timer = setTimeout(() => {
        void expireAction(proposal.id).then(expired => {
          if (expired) return session.respondToToolApproval({ toolCallId: event.toolCallId, decision: 'decline' });
        }).catch(error => this.report(error));
      }, APPROVAL_TTL_MS + 100);
      timer.unref();
    } catch (error) {
      await (await stateDb()).execute({ sql: "UPDATE actions SET status = 'failed', result = ? WHERE id = ? AND status = 'pending'", args: [String(error), proposal.id] });
      await session.respondToToolApproval({ toolCallId: event.toolCallId, decision: 'decline' });
      throw error;
    }
  }

  async onCardAction(event: CardActionEvent) {
    const value = cardDecision.safeParse(event.action.value);
    if (!value.success) return;
    const stored = await getAction(value.data.approvalId);
    if (!stored || stored.chat_id !== event.chatId) return;
    // Older approvals have no chat_type and retain the original chat allowlist check.
    if (!isAuthorizedCaller({ userId: event.operator.openId, chatId: event.chatId, chatType: stored.chat_type ?? 'p2p' })) return;
    if (stored.kind === 'message_send' && !config.allowedUsers.has(event.operator.openId)) return;
    const decision = await decideAction(value.data.approvalId, {
      userId: event.operator.openId, chatId: event.chatId,
    }, value.data.decision === 'approve', async (action, key) => {
      const token = (action.kind === 'calendar_create' || action.kind === 'calendar_update') && action.permissionMode === 'user'
        ? await userAccessToken(event.operator.openId) : undefined;
      return this.office.execute(action, key, token ?? undefined);
    }, async (stored, approved) => {
      const session = stored.session_id ? this.sessions.get(stored.session_id) : undefined;
      if (!session || !stored.tool_call_id) throw new Error('Original agent tool run has expired');
      await session.respondToToolApproval({ toolCallId: stored.tool_call_id, decision: approved ? 'approve' : 'decline' });
    });
    if (decision.action) {
      let detail: string | undefined;
      if (decision.status === 'succeeded' && decision.action.kind === 'calendar_create') {
        const action = officeAction.parse(JSON.parse(decision.action.payload));
        const result = decision.result ?? (decision.action.result ? JSON.parse(decision.action.result) : undefined);
        detail = actionResultDetail(action, result);
      }
      await this.channel.updateCard(event.messageId, resolvedCard(decision.status, detail));
    }
  }

  private async runMinutesWorkflow(documentId: string, caller: Caller, replyTo: string) {
    const db = await stateDb();
    const jobId = crypto.randomUUID();
    await db.execute({ sql: 'INSERT INTO workflow_jobs(id, requester_id, chat_id, status, updated_at) VALUES (?, ?, ?, ?, ?)', args: [jobId, caller.userId, caller.chatId, 'running', Date.now()] });
    try {
      const run = await minutesToTasksWorkflow.createRun();
      await db.execute({ sql: 'UPDATE workflow_jobs SET run_id = ? WHERE id = ?', args: [run.runId, jobId] });
      const result = await run.start({ inputData: { documentId, caller } });
      if (result.status !== 'success') throw new Error(`Workflow ended with ${result.status}`);
      await db.execute({ sql: 'UPDATE workflow_jobs SET status = ?, result = ?, updated_at = ? WHERE id = ?', args: ['completed', JSON.stringify(result.result), Date.now(), jobId] });
      await this.channel.send(caller.chatId, { markdown: result.result.notificationDraft }, { replyTo });
    } catch (error) {
      await db.execute({ sql: 'UPDATE workflow_jobs SET status = ?, result = ?, updated_at = ? WHERE id = ?', args: ['failed', String(error), Date.now(), jobId] });
      throw error;
    }
  }
}
