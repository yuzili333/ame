import { z } from 'zod';
import { formatShanghaiTime } from './calendar-time';

const token = z.string().min(1).max(256).regex(/^[\w@.-]+$/);
const text = z.string().trim().min(1).max(20_000);
const calendarTimestamp = z.string().regex(/^\d{10}$/, 'Calendar timestamps must be Unix seconds');
const taskTimestamp = z.string().regex(/^\d{13}$/, 'Task timestamps must be Unix milliseconds');

export const officeAction = z.discriminatedUnion('kind', [
  z.object({ kind: z.literal('doc_create'), title: text.max(255), content: text.optional(), folderToken: token.optional() }),
  z.object({ kind: z.literal('doc_update'), documentId: token, blockId: token, text }),
  z.object({ kind: z.literal('calendar_create'), calendarId: token.optional(), permissionMode: z.enum(['auto', 'user', 'app']).optional(), summary: text.max(255), description: text.optional(), startTime: calendarTimestamp, endTime: calendarTimestamp }),
  z.object({ kind: z.literal('calendar_update'), calendarId: token, permissionMode: z.enum(['user', 'app']).optional(), eventId: token, summary: text.max(255).optional(), description: text.optional(), startTime: calendarTimestamp.optional(), endTime: calendarTimestamp.optional() }),
  z.object({ kind: z.literal('task_create'), summary: text.max(255), description: text.optional(), dueTimestamp: taskTimestamp.optional() }),
  z.object({ kind: z.literal('task_update'), taskId: token, summary: text.max(255).optional(), description: text.optional(), dueTimestamp: taskTimestamp.optional() }),
  z.object({ kind: z.literal('message_send'), targetChatId: token, text }),
]);

export type OfficeAction = z.infer<typeof officeAction>;

export function actionSummary(action: OfficeAction): string {
  switch (action.kind) {
    case 'doc_create': return `创建文档：${action.title}${action.content ? `；正文：${action.content.slice(0, 180)}` : ''}`;
    case 'doc_update': return `修改文档 ${action.documentId} 的块 ${action.blockId}：${action.text.slice(0, 180)}`;
    case 'calendar_create': return `以${action.permissionMode === 'user' ? '用户' : '应用'}身份在日历 ${action.calendarId ?? '未指定'} 创建日程：${action.summary}（北京时间 ${formatShanghaiTime(action.startTime)}—${formatShanghaiTime(action.endTime)}）`;
    case 'calendar_update': return `以${action.permissionMode === 'user' ? '用户' : '应用'}身份修改日程 ${action.eventId}：${action.summary ?? '时间或说明'}${action.startTime || action.endTime ? `（北京时间 ${action.startTime ? formatShanghaiTime(action.startTime) : '原开始时间'}—${action.endTime ? formatShanghaiTime(action.endTime) : '原结束时间'}）` : ''}`;
    case 'task_create': return `创建任务：${action.summary}`;
    case 'task_update': return `修改任务 ${action.taskId}：${action.summary ?? '说明或截止时间'}`;
    case 'message_send': return `向会话 ${action.targetChatId} 发送：${action.text.slice(0, 180)}`;
  }
}

export function actionResultDetail(action: OfficeAction, result: unknown): string | undefined {
  if (action.kind !== 'calendar_create') return undefined;
  const event = (result as { event?: { event_id?: unknown; app_link?: unknown } } | null)?.event;
  const lines = [actionSummary(action)];
  if (typeof event?.event_id === 'string') lines.push(`事件 ID：${event.event_id}`);
  if (typeof event?.app_link === 'string') {
    try {
      const link = new URL(event.app_link);
      if (link.protocol === 'https:') lines.push(`[打开日程](${link.toString()})`);
    } catch { /* Ignore an invalid link returned by the remote API. */ }
  }
  return lines.join('\n\n');
}
