import { createTool } from '@mastra/core/tools';
import { z } from 'zod';
import type { Caller } from '../../identity';
import { officeAction, type OfficeAction } from '../../office/actions';
import { getOfficeApi } from '../../runtime/office-bridge';
import { requestOfficeApproval } from '../../runtime/approval-bridge';
import { requestCalendarPermission } from '../../office/permission-choice';
import { reconcileRelativeCalendarDate } from '../../office/calendar-time';

const token = z.string().min(1).max(256).regex(/^[\w@.-]+$/);
const time = z.string().regex(/^\d{10}$/);

function callerFrom(context: { requestContext: { get: (key: string) => unknown } }): Caller {
  const value = context.requestContext.get('caller') as Caller | undefined;
  if (!value?.userId || !value.chatId || !value.chatType) throw new Error('Trusted Feishu caller context is required');
  return value;
}

function actionTool<T extends OfficeAction['kind']>(kind: T, description: string) {
  const schema = officeAction.options.find(option => option.shape.kind.value === kind)!;
  return createTool({
    id: `office_${kind}`,
    description,
    inputSchema: (schema as z.ZodObject<z.ZodRawShape>).omit({ kind: true }),
    execute: async (input, context) => {
      const caller = callerFrom(context);
      let action = { ...input, kind } as OfficeAction;
      if (action.kind === 'calendar_create') {
        const originalMessage = context.requestContext.get('originalMessage');
        const messageCreatedAt = context.requestContext.get('messageCreatedAt');
        if (typeof originalMessage === 'string' && typeof messageCreatedAt === 'number') {
          action = reconcileRelativeCalendarDate(action, originalMessage, messageCreatedAt);
        }
      }
      if (action.kind === 'calendar_create' || action.kind === 'calendar_update') return requestCalendarPermission(caller, action);
      return requestOfficeApproval(caller, action);
    },
  });
}

export const readDocumentTool = createTool({
  id: 'office_read_document', description: 'Read an app-accessible Feishu document by document ID.',
  inputSchema: z.object({ documentId: token }),
  execute: async ({ documentId }) => getOfficeApi().readDocument(documentId),
});
export const readCalendarTool = createTool({
  id: 'office_read_calendar', description: 'List events in an app-accessible calendar between Unix timestamps.',
  inputSchema: z.object({ calendarId: token, startTime: time, endTime: time }),
  execute: async ({ calendarId, startTime, endTime }) => getOfficeApi().readCalendar(calendarId, startTime, endTime),
});
export const readTaskTool = createTool({
  id: 'office_read_task', description: 'Read an app-accessible Feishu task by task GUID.',
  inputSchema: z.object({ taskId: token }),
  execute: async ({ taskId }) => getOfficeApi().readTask(taskId),
});

export const createDocumentTool = actionTool('doc_create', 'Propose creating a Feishu document. Requires requester approval.');
export const updateDocumentTool = actionTool('doc_update', 'Propose replacing the text of one Feishu document block. Requires requester approval.');
export const createCalendarTool = actionTool('calendar_create', 'Create a calendar event. Omit calendarId for the requester personal calendar. Set permissionMode=user for personal calendar, app for a shared calendar. If user permission is missing, ask the requester to choose and authorize before sending any write approval card.');
export const updateCalendarTool = actionTool('calendar_update', 'Update a calendar event. Set permissionMode=user when modifying the requester personal calendar, app for an app-accessible shared calendar. Missing user permission triggers a question before approval.');
export const createTaskTool = actionTool('task_create', 'Propose creating a Feishu task. Requires requester approval.');
export const updateTaskTool = actionTool('task_update', 'Propose updating a Feishu task. Requires requester approval.');
export const sendMessageTool = actionTool('message_send', 'Propose sending a message to another allowlisted Feishu chat. Only users in FEISHU_ALLOWED_USERS may use this tool; requester approval is required.');

export const officeTools = {
  readDocumentTool, readCalendarTool, readTaskTool,
  createDocumentTool, updateDocumentTool, createCalendarTool, updateCalendarTool,
  createTaskTool, updateTaskTool, sendMessageTool,
};
