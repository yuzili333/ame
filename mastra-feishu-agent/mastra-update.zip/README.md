# Mastra 飞书办公智能体

独立的 TypeScript 服务。飞书官方 Node SDK 的 WebSocket 长连接处理私聊、群聊与卡片回调；Mastra AgentController 管理会话，Memory/LibSQL 保存上下文，Workspace 提供文件、命令与 Skills，Workflow 处理会议纪要，Studio 提供本机调试。

## 准备

1. Windows 11 云桌面安装 Node.js 22.13+ 和 npm，在本目录执行 `npm ci`。
2. 复制 `.env.example` 为 `.env` 并填写飞书应用 ID、密钥、私有化域名、模型代理 URL 与模型名。`FEISHU_DOMAIN` 为完整的 `https://` 内网域名；`MODEL_PROXY_BASE_URL` 填 API 基础路径（例如 `https://api.siliconflow.cn/v1`），不要附加 `/chat/completions`。Gateway 和 Studio 中注册的 Agent 共用 `MODEL_PROXY_BASE_URL`、`MODEL_PROXY_MODEL`、`MODEL_PROXY_API_KEY`。`MODEL_PROXY_MODEL` 可以写 `deepseek-ai/DeepSeek-V4.1-Flash`，也可以写 Studio 显示的 `siliconflow-cn/deepseek-ai/DeepSeek-V4.1-Flash`；调用 OpenAI 兼容接口时会自动去掉 `siliconflow-cn/` 前缀。若在 Studio 的 SiliconFlow CN 模型选择器中调试，还需将 `SILICONFLOW_CN_API_KEY` 设为同一密钥；使用 SiliconFlow CN 地址时，服务启动会校验两者一致。模型代理需要提供 OpenAI 兼容的流式 `tool_calls`，由代理完成 SSO。
3. 飞书开发者后台启用机器人、**长连接事件订阅**，订阅 `im.message.receive_v1`；在卡片回调中订阅 `card.action.trigger`。把机器人加入需要服务的群，并确保应用可访问目标文档、日历与任务。
4. 在权限管理中，按照租户当前版本的接口权限清单授予：接收与发送消息、更新消息卡片，创建/读取/编辑新版文档，读取/创建/更新日历日程，以及读取/创建/更新任务。共享资源默认使用应用身份。个人日历使用用户身份，并要求用户单独授权；私有化环境缺失相应接口时会明确报错，不会借用另一种身份代执行。具体权限以 [飞书开放平台的接口页面](https://open.feishu.cn/document/) 为准。
5. 将需要私聊机器人的用户 `open_id` 写入 `FEISHU_ALLOWED_USERS`，以逗号分隔；`FEISHU_ALLOWED_CHATS` 用于允许私聊和代发消息的目标会话。首次启动前可先留空：私聊机器人发送 `/id` 获取自己的 `open_id` 与私聊 `chat_id`。将机器人邀请进群后，群内任意成员直接 `@机器人` 即可对话，无须为新成员或新群修改 `.env`、重启网关。群聊普通消息仍须 @机器人。`/id` 只用于查询 ID，不能赋予私聊或跨会话代发权限。`open_id` 与应用绑定，须从这个机器人获取。

## 运行

分别打开两个终端：

```powershell
npm run gateway
npm run dev
```

也可用 `powershell -ExecutionPolicy Bypass -File .\scripts\start-windows.ps1 -Mode both`。Mastra Studio 与 API 只绑定 `127.0.0.1:4111`，访问 `http://127.0.0.1:4111/studio`。在 Studio 中查看 Agent、Workflow、Tools 与 Traces；飞书写工具的实地审批需要同时运行网关。生产运行前执行 `npm run build`，再使用 `npm run start` 启动已构建的本机 Studio/API。网关仍以 `npm run gateway` 单独启动。

在 Studio 中调试需要审批的工具时，给 Request Context 设置 `{"caller":{"userId":"<允许的 open_id>","chatId":"<允许的私聊 chat_id>","chatType":"p2p"}}`；群聊调试可使用机器人所在群的 `chat_id` 与 `"chatType":"group"`，不需要群白名单。Workflow 输入还需要相同的 `caller` 对象。Studio 使用应用凭据直接发审批卡片，网关负责接收确认回调。

## 功能与审批

- 私聊按用户独立记忆；群聊按群共享，和私聊隔离。机器人所在群的成员均可通过 @机器人使用 Agent；邀请机器人入群即意味着该群成员可访问 Agent 的对话及机器人应用有权读取的办公资源。私聊仍要求用户和私聊 ID 均获准；跨会话代发仅限 `FEISHU_ALLOWED_USERS` 内用户，目标会话仍需列入 `FEISHU_ALLOWED_CHATS`。群内写操作仍由原请求者逐项审批。消息 ID 在本地 SQLite 中去重，同一会话串行处理。
- 文档、日程与任务的读取直接用机器人应用身份执行；新建、更新、代发到其他会话的消息先发卡片，原请求者在 30 分钟内逐次确认。普通当前会话回复直接发送。文档更新针对指定文本块；新建文档可包含正文。
- 创建个人日程时，Agent 使用用户身份；若尚无用户日历授权，机器人先发文字询问选择“用户权限”或“应用权限”。选择用户权限会收到 OAuth 授权链接，授权账号必须与原请求者的 `open_id` 一致；选择应用权限时需要提供机器人可写的共享日历 ID。权限选择和授权阶段都不会发送写入审批卡片；目标身份及日历确定后才发卡片。群聊中的选择回复仍须 @机器人，且只有原请求者能继续该请求。回复“取消”会放弃。用户令牌在本地 SQLite 中加密保存，到期时使用一次性刷新令牌更新；用户身份失败不会自动回退应用身份。若旧令牌缺少日历权限，选择“用户权限”会发起新的授权链接；授权失败后 30 分钟内可直接回复“重新授权”。新申请会替代该会话的失败授权记录。
- 日程的相对日期以飞书原消息时间和北京时间为准；工具在发起审批前校正“今天／明天／后天”及完整年月日与模型时间戳不符的情况。审批卡片显示可读的北京时间，执行成功后展示实际创建的日程时间和飞书日程链接。
- 文件工具以 `AGENT_WORKSPACE_DIR` 为根目录。命令从该目录启动，但继承 Windows 进程的文件权限；应以受限服务账号运行。文件写入、编辑、删除、命令执行与定时任务使用 Mastra 工具审批。Skills 位于 `workspace/skills/`。外部 MCP 服务仅从 `MCP_SERVERS_JSON` 中连接，且只向 Agent 暴露 `allowedTools` 列表中的工具；MCP 工具调用也需审批。
- 输入 `/minutes <documentId>` 执行“读会议纪要 → 提取最多 10 个待办 → 每项任务单独提请审批 → 生成通知草稿”。草稿作为当前会话回复；若要向别处发送，需另行调用代发消息工具并审批。
- 审批记录、消息去重与 Workflow 状态位于 `data/state.db`；Mastra Memory/Controller 状态位于 `data/mastra.db`。重启后，未决的 Office 写入卡片在有效期内仍可确认；挂起的本地/MCP 工具审批与运行中的 Workflow 标记为 `interrupted`，不会重放。外部接口失败后不自动重试，以避免不确定提交造成重复写入。

### 个人日历授权配置

在飞书开发者后台为应用开通用户身份的 `calendar:calendar`、`calendar:calendar:readonly` 和 `offline_access` 权限，并在“安全设置”登记 `FEISHU_OAUTH_REDIRECT_URI`。填写 `.env` 中的 OAuth 授权页 URL（例如 `https://accounts.feishu.cn/open-apis/authen/v1/authorize`）、令牌 URL（例如 `https://open.feishu.cn/open-apis/authen/v2/oauth/token`）以及回调 URL。私有化部署应使用其实际内网域名。回调服务由网关在 `FEISHU_OAUTH_LISTEN_HOST:FEISHU_OAUTH_LISTEN_PORT` 启动；当前示例使用 `http://localhost:4000/auth/feishu/callback`，因此授权页面必须在运行网关的同一台电脑上打开。若飞书客户端运行在其他设备，应改为客户端可访问的内网 HTTPS 地址，并在开发者后台同步登记、通过反向代理转发到监听端口。Studio 仍只在本机监听。`FEISHU_TOKEN_ENCRYPTION_KEY` 应设置为长期稳定的随机密钥并妥善备份；重启后要能解密已保存的用户令牌。未配置这些变量时，应用身份的共享日历操作仍可用，选择用户权限会得到明确的配置错误。

新增日历读取权限后，已授权用户需要重新打开授权链接以取得新范围。

用户授权流程依次为：文字选择身份 → 打开授权链接 → 回调校验原请求者身份 → 查询其主日历写入权限 → 发送写入审批卡片。已有用户令牌也会在发卡前检查目标日历的写入权限；权限不足时重新追问并引导补充授权。授权链接及卡片均在 30 分钟内有效；审批依旧只接受原请求者、原会话的一次确认。授权成功本身不创建日程。联调时应额外验证回调 URL 可达、用户身份与应用身份各自的日历范围、授权拒绝、错误账号、令牌刷新和重复回调。

## 调试与验收

```powershell
npm run typecheck
npm test
npm run build
```

自动化测试使用内存中的飞书传输替身，不需要应用凭据。Windows 私有化联调仍需逐项验证：长连接建立、私聊/群聊 @、卡片回调身份、文档/日程/任务读取与写入、模型代理的流式工具调用、MCP 服务以及 Studio 四个视图。若 `card.action.trigger` 或目标 OpenAPI 在私有化版本不可用，必须保持对应写操作不可用，并依据实际租户接口再适配。

参考：[Mastra Agent Harness](https://mastra.ai/templates/agent-harness)、[Mastra Harness](https://mastra.ai/docs/harness/overview)、[Mastra Workflow](https://mastra.ai/docs/workflows/overview)、[Mastra Studio](https://mastra.ai/docs/studio/overview)、[飞书 Node SDK](https://github.com/larksuite/node-sdk/blob/main/docs/channel.md)。
